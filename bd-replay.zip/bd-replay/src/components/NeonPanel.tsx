import { ReactNode } from 'react';

interface NeonPanelProps {
  title?: string;
  children: ReactNode;
  className?: string;
}

/**
 * NeonPanel wraps content in a stylized glassy container with neon borders.
 */
export default function NeonPanel({ title, children, className = '' }: NeonPanelProps) {
  return (
    <section
      className={`relative border border-gray-700 bg-gray-900/60 backdrop-blur-md p-4 rounded-lg shadow-neon ${className}`}
    >
      {title && <h2 className="mb-2 text-primary font-semibold text-lg">{title}</h2>}
      {children}
    </section>
  );
}
"use client";
import { useState } from 'react';

interface ShareReplayDialogProps {
  link: string;
}

/**
 * ShareReplayDialog displays a modal with a shareable link and copy functionality.
 */
export default function ShareReplayDialog({ link }: ShareReplayDialogProps) {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    await navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/70 z-50">
      <div className="bg-gray-900 border border-gray-700 p-6 rounded-lg w-80">
        <h3 className="text-primary text-lg font-semibold mb-4">Share Replay</h3>
        <p className="text-xs text-gray-400 mb-2">Copy the link below to share your replay.</p>
        <div className="flex items-center gap-2 mb-4">
          <input
            readOnly
            value={link}
            className="flex-1 bg-gray-800 border border-gray-600 rounded px-2 py-1 text-xs text-gray-300"
          />
          <button
            onClick={handleCopy}
            className="px-3 py-1 bg-primary text-black rounded text-xs font-medium hover:bg-orange-500"
          >
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
        <button
          onClick={() => {
            const event = new CustomEvent('close-share');
            window.dispatchEvent(event);
          }}
          className="text-xs text-gray-400 hover:text-primary"
        >
          Close
        </button>
      </div>
    </div>
  );
}
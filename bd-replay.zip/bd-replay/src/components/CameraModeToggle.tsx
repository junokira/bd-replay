"use client";
import { useState } from 'react';

export type CameraMode = 'follow' | 'free' | 'orbit' | 'firstPerson';

interface CameraModeToggleProps {
  mode: CameraMode;
  onChange: (mode: CameraMode) => void;
}

/**
 * CameraModeToggle allows switching between different camera modes: following the original path, free camera, orbit, etc.
 */
export default function CameraModeToggle({ mode, onChange }: CameraModeToggleProps) {
  const modes: Array<{ key: CameraMode; label: string }> = [
    { key: 'follow', label: 'Follow' },
    { key: 'free', label: 'Free' },
    { key: 'orbit', label: 'Orbit' },
    { key: 'firstPerson', label: 'First' },
  ];
  return (
    <div className="inline-flex bg-gray-800 rounded-lg overflow-hidden border border-gray-700">
      {modes.map(({ key, label }) => {
        const active = key === mode;
        return (
          <button
            key={key}
            onClick={() => onChange(key)}
            className={`px-3 py-1 text-xs font-medium ${active ? 'bg-primary text-black' : 'text-gray-400 hover:text-primary'}`}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}
import Link from 'next/link';
import { Replay } from '@lib/types';
import NeonPanel from './NeonPanel';

interface ReplayLibraryProps {
  replays: Replay[];
}

/**
 * ReplayLibrary renders a list of the user's previously created replays.
 */
export default function ReplayLibrary({ replays }: ReplayLibraryProps) {
  if (replays.length === 0) {
    return (
      <NeonPanel title="Your Replays" className="mt-8">
        <p className="text-gray-400">No replays yet. Create your first one!</p>
      </NeonPanel>
    );
  }
  return (
    <NeonPanel title="Your Replays" className="mt-8">
      <ul className="divide-y divide-gray-700">
        {replays.map((replay) => {
          const link = replay.status === 'ready' ? `/replay/${replay.id}` : `/processing/${replay.id}`;
          return (
            <li key={replay.id} className="py-3 flex justify-between items-center">
              <div>
                <Link href={link} className="text-primary hover:underline font-medium">
                  {replay.title || 'Untitled Replay'}
                </Link>
                <div className="text-xs text-gray-500">
                  {new Date(replay.createdAt).toLocaleString()} &mdash; {replay.status}
                </div>
              </div>
              <div className="text-xs text-gray-400">{replay.status}</div>
            </li>
          );
        })}
      </ul>
    </NeonPanel>
  );
}
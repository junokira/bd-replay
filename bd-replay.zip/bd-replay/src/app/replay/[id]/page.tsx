"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import ReplayViewport from '@components/ReplayViewport';
import TimelineScrubber from '@components/TimelineScrubber';
import TelemetryPanel from '@components/TelemetryPanel';
import CameraModeToggle, { CameraMode } from '@components/CameraModeToggle';
import ShareReplayDialog from '@components/ShareReplayDialog';
import { Replay } from '@lib/types';

interface PageProps {
  params: { id: string };
}

export default function ReplayPage({ params }: PageProps) {
  const { id } = params;
  const router = useRouter();
  const [replay, setReplay] = useState<Replay | null>(null);
  const [duration, setDuration] = useState(30);
  const [currentTime, setCurrentTime] = useState(0);
  const [mode, setMode] = useState<CameraMode>('follow');
  const [showShare, setShowShare] = useState(false);
  const [playing, setPlaying] = useState(true);

  // Load replay from localStorage
  useEffect(() => {
    const stored = window.localStorage.getItem('bd-replays');
    if (stored) {
      const replays: Replay[] = JSON.parse(stored);
      const found = replays.find((r) => r.id === id);
      if (found) {
        setReplay(found);
      } else {
        // Unknown id, redirect to library
        router.replace('/library');
      }
    }
  }, [id, router]);

  // Playback timer effect
  useEffect(() => {
    if (!playing) return;
    const interval = setInterval(() => {
      setCurrentTime((t) => {
        const newTime = t + 0.1;
        if (newTime >= duration) {
          return 0;
        }
        return newTime;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [playing, duration]);

  const handleScrub = (time: number) => {
    setCurrentTime(time);
  };

  const handleShareClick = () => {
    setShowShare(true);
  };

  useEffect(() => {
    const handler = () => setShowShare(false);
    window.addEventListener('close-share', handler);
    return () => window.removeEventListener('close-share', handler);
  }, []);

  return (
    <div className="flex flex-col lg:flex-row h-full px-4 py-4 gap-4">
      {/* Left sidebar (optional mini-map placeholder) */}
      <aside className="hidden lg:block lg:w-1/5">
        {/* Potential mini-map or list of camera positions */}
        <TelemetryPanel cameraPosition={[0, 0, 0]} lookAt={[0, 0, 0]} />
      </aside>
      {/* Main 3D viewport area */}
      <div className="flex-1 flex flex-col">
        <div className="flex-1 relative overflow-hidden rounded-lg border border-gray-700">
          <ReplayViewport assetUrl={replay?.assetsUrl} />
          {/* HUD overlay */}
          <div className="absolute top-2 right-2 flex gap-2">
            <button
              onClick={() => setPlaying(!playing)}
              className="px-2 py-1 text-xs bg-gray-800 hover:bg-gray-700 border border-gray-600 rounded"
            >
              {playing ? 'Pause' : 'Play'}
            </button>
            <CameraModeToggle mode={mode} onChange={setMode} />
            <button
              onClick={handleShareClick}
              className="px-2 py-1 text-xs bg-primary text-black rounded hover:bg-orange-500"
            >
              Share
            </button>
          </div>
        </div>
        <div className="mt-2">
          <TimelineScrubber current={currentTime} duration={duration} onScrub={handleScrub} />
        </div>
      </div>
      {/* Right sidebar (metadata) */}
      <aside className="hidden lg:block lg:w-1/5">
        <TelemetryPanel cameraPosition={[Math.sin(currentTime), 0, Math.cos(currentTime)]} lookAt={[0, 0, 0]} />
      </aside>
      {showShare && (
        <ShareReplayDialog link={typeof window !== 'undefined' ? window.location.href : ''} />
      )}
    </div>
  );
}
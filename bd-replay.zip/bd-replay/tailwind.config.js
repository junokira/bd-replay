/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Custom colours for BD Replay theme
        primary: '#ff5c57',
        secondary: '#00d8e5',
        accent: '#ffb400',
      },
      boxShadow: {
        neon: '0 0 10px var(--tw-shadow-color)',
      },
      backgroundImage: {
        noise: "url('data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'160\' height=\'160\' fill-opacity=\'0.02\'><rect width=\'100%\' height=\'100%\' fill=\'#ffffff'/></svg>')",
      },
    },
  },
  plugins: [],
};
import NeonPanel from './NeonPanel';

/**
 * CaptureGuide displays instructions on how to capture a space with a phone.
 */
export default function CaptureGuide() {
  const steps = [
    'Move slowly around the space',
    'Keep objects of interest in view',
    'Avoid blurring the camera',
    'Record 30–90 seconds of footage',
    'Walk in a smooth arc',
    'Capture multiple angles'
  ];
  return (
    <NeonPanel title="Capture Instructions" className="max-w-xl mx-auto mt-8">
      <ol className="list-decimal list-inside space-y-2">
        {steps.map((step) => (
          <li key={step} className="text-gray-300">
            {step}
          </li>
        ))}
      </ol>
    </NeonPanel>
  );
}
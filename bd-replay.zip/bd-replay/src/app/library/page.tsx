"use client";
import { useEffect, useState } from 'react';
import ReplayLibrary from '@components/ReplayLibrary';
import { Replay } from '@lib/types';

export default function LibraryPage() {
  const [replays, setReplays] = useState<Replay[]>([]);
  useEffect(() => {
    const stored = window.localStorage.getItem('bd-replays');
    if (stored) {
      setReplays(JSON.parse(stored));
    }
  }, []);
  return (
    <div className="px-4 py-8">
      <ReplayLibrary replays={replays} />
    </div>
  );
}
"use client";
import { useRef, ChangeEvent } from 'react';
import NeonPanel from './NeonPanel';

interface UploadDropzoneProps {
  onFilesSelected: (files: FileList) => void;
}

/**
 * UploadDropzone provides an input for selecting photos or video from the user's device.
 */
export default function UploadDropzone({ onFilesSelected }: UploadDropzoneProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      onFilesSelected(files);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <NeonPanel title="Upload Footage" className="max-w-md mx-auto mt-8 text-center">
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*,image/*"
        multiple
        hidden
        onChange={handleFileChange}
      />
      <button
        onClick={handleClick}
        className="px-4 py-2 mt-4 bg-primary text-black font-semibold rounded hover:bg-orange-500 transition-colors"
      >
        Select Files
      </button>
      <p className="mt-2 text-xs text-gray-400">Choose 30–90 seconds of video or a set of photos</p>
    </NeonPanel>
  );
}
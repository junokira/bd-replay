"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import ProcessingPipeline, { ProcessingStage } from '@components/ProcessingPipeline';
import { Replay } from '@lib/types';

interface PageProps {
  params: { id: string };
}

/**
 * ProcessingPage simulates the pipeline stages and redirects to the replay viewer once ready.
 */
export default function ProcessingPage({ params }: PageProps) {
  const router = useRouter();
  const { id } = params;
  const [stage, setStage] = useState<ProcessingStage>('uploading');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Simulate progress across stages
    const stageOrder: ProcessingStage[] = [
      'uploading',
      'extracting',
      'estimating',
      'reconstructing',
      'optimizing',
      'ready',
    ];
    let currentStageIndex = 0;
    setStage(stageOrder[currentStageIndex]);
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((p) => {
        const newProgress = p + 0.1;
        if (newProgress >= 1) {
          // Move to next stage
          currentStageIndex++;
          if (stageOrder[currentStageIndex]) {
            setStage(stageOrder[currentStageIndex]);
            return 0;
          } else {
            clearInterval(interval);
            return 1;
          }
        }
        return newProgress;
      });
    }, 500);
    return () => clearInterval(interval);
  }, []);

  // When stage becomes 'ready', update replay status and redirect after a delay
  useEffect(() => {
    if (stage === 'ready') {
      // update localStorage record
      const stored = window.localStorage.getItem('bd-replays');
      if (stored) {
        const replays: Replay[] = JSON.parse(stored);
        const idx = replays.findIndex((r) => r.id === id);
        if (idx >= 0) {
          replays[idx].status = 'ready';
          replays[idx].updatedAt = new Date().toISOString();
          window.localStorage.setItem('bd-replays', JSON.stringify(replays));
        }
      }
      const timer = setTimeout(() => {
        router.replace(`/replay/${id}`);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [stage, id, router]);

  return (
    <div className="px-4 py-8 flex flex-col items-center">
      <ProcessingPipeline stage={stage} progress={progress} />
    </div>
  );
}
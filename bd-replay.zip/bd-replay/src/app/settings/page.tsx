export default function SettingsPage() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-semibold mb-4 text-primary">Settings</h1>
      <p className="text-gray-400">Settings are not yet implemented in this MVP.</p>
    </div>
  );
}
/*
 * BD Replay frontend logic
 *
 * This file centralises all JavaScript used across the BD Replay MVP.
 * Functions are namespaced under `bdReplay` for clarity. Each page
 * declares a `data-page` attribute on the `<body>` element; during
 * `DOMContentLoaded` a corresponding initialiser is invoked. Data
 * persistence is achieved via `localStorage`, allowing replays to be
 * created, updated and listed without any backend.  Progress on the
 * processing page is simulated via a timer. The replay viewer page
 * includes a simple timeline slider, telemetry readouts and a modal
 * for sharing a link.
 */

(function () {
  /**
   * Generate a pseudo‑random identifier for a replay. Uses current
   * timestamp combined with a random base36 string to minimise
   * collisions.
   * @returns {string}
   */
  function generateId() {
    return (
      Date.now().toString(36) + Math.random().toString(36).slice(2)
    );
  }

  /**
   * Read and parse the list of saved replays from localStorage.
   * @returns {Array}
   */
  function loadReplays() {
    try {
      const raw = localStorage.getItem('bdReplays');
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error('Failed to load replays', e);
      return [];
    }
  }

  /**
   * Persist the given array of replays to localStorage.
   * @param {Array} replays
   */
  function saveReplays(replays) {
    try {
      localStorage.setItem('bdReplays', JSON.stringify(replays));
    } catch (e) {
      console.error('Failed to save replays', e);
    }
  }

  /**
   * Find a replay by its identifier.
   * @param {string} id
   * @returns {Object|undefined}
   */
  function findReplayById(id) {
    const replays = loadReplays();
    return replays.find((r) => r.id === id);
  }

  // Expose utility functions globally for debugging or external use.
  window.bdReplay = {
    generateId,
    loadReplays,
    saveReplays,
    findReplayById,
  };

  /**
   * On DOM ready, dispatch to the appropriate page initialiser based
   * on the `data-page` attribute set on the <body> element.
   */
  document.addEventListener('DOMContentLoaded', () => {
    const page = document.body.dataset.page;
    switch (page) {
      case 'upload':
        initUploadPage();
        break;
      case 'processing':
        initProcessingPage();
        break;
      case 'replay':
        initReplayPage();
        break;
      case 'library':
        initLibraryPage();
        break;
      default:
        // no specific initialiser for home, capture or settings
        break;
    }
  });

  /**
   * Initialise the upload page. Attaches a click handler to the
   * upload button which stores the selected file metadata and
   * redirects to the processing page.
   */
  function initUploadPage() {
    const fileInput = document.getElementById('file-input');
    const uploadBtn = document.getElementById('upload-btn');
    if (!fileInput || !uploadBtn) return;
    uploadBtn.addEventListener('click', () => {
      const file = fileInput.files && fileInput.files[0];
      if (!file) {
        alert('Please select a media file to upload.');
        return;
      }
      const id = generateId();
      const replays = loadReplays();
      replays.push({
        id,
        name: file.name || 'Untitled',
        created: Date.now(),
        status: 'processing',
      });
      saveReplays(replays);
      // Redirect to processing page with the new id
      window.location.href = `processing.html?id=${encodeURIComponent(id)}`;
    });
  }

  /**
   * Initialise the processing page. Simulates a reconstruction
   * pipeline by incrementing a progress bar over time. Once
   * complete, updates the replay status and reveals a link to the
   * replay viewer.
   */
  function initProcessingPage() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const statusText = document.getElementById('status-text');
    const progressBar = document.getElementById('progress-bar');
    const completeMessage = document.getElementById('complete-message');
    const exploreBtn = document.getElementById('explore-btn');
    if (!id || !statusText || !progressBar || !completeMessage) {
      return;
    }
    const replay = findReplayById(id);
    if (!replay) {
      statusText.textContent = 'Replay not found.';
      return;
    }
    let progress = 0;
    const stages = [
      'Building your replay',
      'Mapping camera movement',
      'Reconstructing the scene',
      'Optimizing replay',
      'Ready to explore',
    ];
    function update() {
      progress += 1;
      // Determine current stage based on progress
      const stageIndex = Math.min(
        Math.floor((progress / 100) * stages.length),
        stages.length - 1
      );
      statusText.textContent = stages[stageIndex];
      progressBar.style.width = `${progress}%`;
      if (progress >= 100) {
        clearInterval(timer);
        // Update replay status in storage
        const replays = loadReplays();
        const idx = replays.findIndex((r) => r.id === id);
        if (idx !== -1) {
          replays[idx].status = 'ready';
          saveReplays(replays);
        }
        // Show completion message and explore button
        completeMessage.classList.remove('hide');
        if (exploreBtn) {
          exploreBtn.onclick = () => {
            window.location.href = `replay.html?id=${encodeURIComponent(id)}`;
          };
        }
      }
    }
    // Update every 100ms (approx. 10 seconds total)
    const timer = setInterval(update, 100);
  }

  /**
   * Initialise the replay viewer page. Loads the replay record and
   * sets up UI controls for mode toggling, timeline scrubbing,
   * telemetry readouts and sharing.
   */
  function initReplayPage() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const viewport = document.getElementById('viewport');
    const modeBtn = document.getElementById('mode-btn');
    const shareBtn = document.getElementById('share-btn');
    const timeline = document.getElementById('timeline');
    const telemetry = document.getElementById('telemetry');
    const modal = document.getElementById('share-modal');
    const shareLink = document.getElementById('share-link');
    const modalClose = document.getElementById('modal-close');
    if (!id || !viewport || !modeBtn || !shareBtn || !timeline || !telemetry) {
      return;
    }
    const replay = findReplayById(id);
    if (!replay || replay.status !== 'ready') {
      viewport.textContent = 'Replay not found or not ready.';
      return;
    }
    // State variables for the viewer
    let mode = 'orbit';
    let progress = 0;
    // Function to update telemetry values based on progress
    function updateTelemetry() {
      const t = progress / 100;
      const x = (t * 10).toFixed(2);
      const y = (t * 3).toFixed(2);
      const z = (t * 5).toFixed(2);
      telemetry.textContent = `X: ${x}, Y: ${y}, Z: ${z}`;
    }
    // Timeline slider input handler
    timeline.addEventListener('input', (e) => {
      const value = parseInt(e.target.value, 10);
      progress = value;
      updateTelemetry();
    });
    // Mode toggle handler
    modeBtn.addEventListener('click', () => {
      mode = mode === 'orbit' ? 'first-person' : 'orbit';
      modeBtn.textContent =
        mode === 'orbit' ? 'Switch to First-person' : 'Switch to Orbit';
    });
    // Share modal open
    shareBtn.addEventListener('click', () => {
      if (modal && shareLink) {
        shareLink.value = window.location.href;
        modal.classList.remove('hide');
      }
    });
    // Share modal close
    if (modalClose) {
      modalClose.addEventListener('click', () => {
        modal.classList.add('hide');
      });
    }
    // Initialise telemetry on load
    updateTelemetry();
  }

  /**
   * Initialise the library page. Generates a list of saved replays
   * with links to the processing or replay pages depending on the
   * status. Also configures a global share modal.
   */
  function initLibraryPage() {
    const listContainer = document.getElementById('replay-list');
    const modal = document.getElementById('share-modal');
    const shareLink = document.getElementById('share-link');
    const modalClose = document.getElementById('modal-close');
    if (!listContainer) return;
    const replays = loadReplays();
    if (!replays.length) {
      listContainer.textContent = 'No replays yet. Upload media to get started.';
      return;
    }
    // Sort by most recent first
    replays.sort((a, b) => b.created - a.created);
    replays.forEach((replay) => {
      const wrapper = document.createElement('div');
      wrapper.className = 'panel neon';
      const link = document.createElement('a');
      link.href =
        (replay.status === 'ready' ? 'replay.html?id=' : 'processing.html?id=') +
        encodeURIComponent(replay.id);
      link.textContent = replay.name || `Replay ${replay.id}`;
      link.style.color = 'var(--accent-primary)';
      link.style.textDecoration = 'none';
      const meta = document.createElement('div');
      meta.className = 'meta';
      const date = new Date(replay.created).toLocaleString();
      meta.textContent = `${date} – ${replay.status}`;
      // Share button inside library item
      const shareBtn = document.createElement('button');
      shareBtn.className = 'button';
      shareBtn.textContent = 'Share';
      shareBtn.style.marginTop = '0.5rem';
      shareBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (modal && shareLink) {
          const base = window.location.href.replace(/library.html.*/, '');
          shareLink.value = `${base}${replay.status === 'ready' ? 'replay.html?id=' : 'processing.html?id='}${encodeURIComponent(
            replay.id
          )}`;
          modal.classList.remove('hide');
        }
      });
      wrapper.appendChild(link);
      wrapper.appendChild(meta);
      wrapper.appendChild(shareBtn);
      listContainer.appendChild(wrapper);
    });
    // Hook up modal close button
    if (modalClose) {
      modalClose.addEventListener('click', () => {
        modal.classList.add('hide');
      });
    }
  }
})();
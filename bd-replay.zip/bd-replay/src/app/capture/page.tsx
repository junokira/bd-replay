import Link from 'next/link';
import CaptureGuide from '@components/CaptureGuide';

export default function CapturePage() {
  return (
    <div className="px-4 py-8">
      <CaptureGuide />
      <div className="mt-6 text-center">
        <Link
          href="/upload"
          className="inline-block px-6 py-3 bg-primary text-black font-semibold rounded-lg shadow hover:bg-orange-500 transition-colors"
        >
          Continue to Upload
        </Link>
      </div>
    </div>
  );
}
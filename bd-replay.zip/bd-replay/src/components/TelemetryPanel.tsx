import NeonPanel from './NeonPanel';

interface TelemetryPanelProps {
  cameraPosition?: [number, number, number];
  lookAt?: [number, number, number];
}

/**
 * TelemetryPanel displays information about the current camera state and replay metadata.
 */
export default function TelemetryPanel({ cameraPosition, lookAt }: TelemetryPanelProps) {
  return (
    <NeonPanel title="Telemetry" className="text-xs p-2">
      <div className="space-y-1">
        <div>
          <span className="text-gray-400">Position:</span>{' '}
          <span className="text-gray-200">
            {cameraPosition ? cameraPosition.map((n) => n.toFixed(2)).join(', ') : 'N/A'}
          </span>
        </div>
        <div>
          <span className="text-gray-400">Look at:</span>{' '}
          <span className="text-gray-200">
            {lookAt ? lookAt.map((n) => n.toFixed(2)).join(', ') : 'N/A'}
          </span>
        </div>
        <div>
          <span className="text-gray-400">FOV:</span> <span className="text-gray-200">90°</span>
        </div>
      </div>
    </NeonPanel>
  );
}
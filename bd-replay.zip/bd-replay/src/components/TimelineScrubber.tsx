"use client";
import { useState, ChangeEvent } from 'react';

interface TimelineScrubberProps {
  /**
   * The current time in seconds.
   */
  current: number;
  /**
   * Total duration in seconds.
   */
  duration: number;
  /**
   * Invoked when the user scrubs the timeline.
   */
  onScrub: (time: number) => void;
}

/**
 * TimelineScrubber renders a range input with custom styling to control replay progress.
 */
export default function TimelineScrubber({ current, duration, onScrub }: TimelineScrubberProps) {
  const [value, setValue] = useState(current);

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const newValue = parseFloat(e.target.value);
    setValue(newValue);
    onScrub(newValue);
  };

  return (
    <div className="w-full flex items-center gap-2">
      <input
        type="range"
        min={0}
        max={duration}
        step={0.01}
        value={value}
        onChange={handleChange}
        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
      />
      <span className="text-xs text-gray-400 w-16 text-right">
        {value.toFixed(1)} / {duration.toFixed(1)}s
      </span>
    </div>
  );
}
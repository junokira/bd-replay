"use client";
import { useRef, useEffect } from 'react';

interface ReplayViewportProps {
  /**
   * URL to the 3D asset; optional for the mock viewer.
   */
  assetUrl?: string;
}

/**
 * ReplayViewport is responsible for rendering the 3D scene. In the MVP
 * we display a placeholder element and provide hooks for integrating
 * a proper React Three Fiber viewer in the future.
 */
export default function ReplayViewport({ assetUrl }: ReplayViewportProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Placeholder: this effect could mount a Three.js scene later.
    const el = containerRef.current;
    if (!el) return;
    // Provide a simple background to suggest a viewport.
    el.style.background = 'radial-gradient(circle at center, rgba(255,255,255,0.05), rgba(0,0,0,1))';
    el.style.border = '1px solid #333';
    el.style.position = 'relative';
  }, []);

  return (
    <div
      ref={containerRef}
      className="w-full h-full flex items-center justify-center text-gray-500 select-none"
    >
      <span className="text-sm">3D viewer placeholder</span>
    </div>
  );
}
"use client";
import Link from 'next/link';
import { ReactNode } from 'react';

interface BDLayoutProps {
  children: ReactNode;
}

/**
 * BDLayout provides the main shell with a header and optional footer.
 * It applies the dark theme and neon styling consistent with the BD Replay brand.
 */
export default function BDLayout({ children }: BDLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-gray-800 p-4 flex items-center justify-between">
        <Link href="/" className="text-primary font-bold text-xl tracking-widest">
          BD REPLAY
        </Link>
        <nav className="flex gap-4 text-sm">
          <Link href="/library" className="hover:text-primary transition-colors">Library</Link>
          <Link href="/capture" className="hover:text-primary transition-colors">Capture</Link>
          <Link href="/settings" className="hover:text-primary transition-colors">Settings</Link>
        </nav>
      </header>
      <main className="flex-1 flex flex-col">{children}</main>
      <footer className="text-center text-xs text-gray-600 py-2 border-t border-gray-800">
        © {new Date().getFullYear()} BD Replay. All rights reserved.
      </footer>
    </div>
  );
}
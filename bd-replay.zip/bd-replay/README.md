# BD Replay

**BD Replay** is a phone‑based spatial memory replay platform. This V1 implementation focuses on the frontend experience, allowing users to capture footage with their phone, upload it to the app, and replay the scene in an interactive 3D viewer. The design takes cues from futuristic noir interfaces with dark backgrounds, neon accents, and glitchy transitions.

## Features

* Landing page with hero copy and call to action
* Capture guide with clear instructions on how to record footage
* Upload flow with drag‑and‑drop (file input) and mock processing pipeline
* Processing page that steps through upload, extraction, camera mapping, reconstruction, optimisation and readiness
* Library page that lists previously created replays
* Interactive replay viewer with
  * 3D viewport placeholder (ready to integrate with Three.js/React Three Fiber)
  * Timeline scrubber
  * Camera mode toggle (follow, free, orbit, first person)
  * Play/pause controls
  * Telemetry panels
  * Share link dialog

## Architecture

This project uses the Next.js **app router** (React Server Components) and TypeScript. Tailwind CSS provides the styling. The current implementation is fully client‑side and uses `localStorage` to simulate backend persistence. Pages live in the `src/app` directory and components in `src/components`.

To connect a real reconstruction pipeline, replace the mock logic in the upload and processing pages with API calls to a backend service. The `ReplayViewport` component is a stub where a proper 3D viewer should be mounted. See `src/lib/types.ts` for data model definitions.

## Getting Started

1. Install dependencies:

```bash
npm install
```

2. Run the development server:

```bash
npm run dev
```

3. Open `http://localhost:3000` to view the app.

> **Note:** Because this environment restricts external network access, dependencies may need to be installed offline or vendored locally. The provided codebase does not fetch any remote assets at runtime and is designed to be self‑contained.

## Next Steps

* Integrate a backend service for processing uploaded footage (FFmpeg, COLMAP, Gaussian Splatting)
* Use React Three Fiber or Three.js to render the reconstructed 3D scene
* Persist replays in a database (e.g. Supabase) and implement authentication
* Add WebXR support for VR devices

"use client";
import { useRouter } from 'next/navigation';
import UploadDropzone from '@components/UploadDropzone';
import { Replay } from '@lib/types';

export default function UploadPage() {
  const router = useRouter();

  const handleFilesSelected = (files: FileList) => {
    // Generate a simple ID for the new replay
    const id = Math.random().toString(36).substring(2, 10);
    // Create a new replay entry
    const newReplay: Replay = {
      id,
      title: `Replay ${new Date().toLocaleString()}`,
      status: 'processing',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    // Persist replays to localStorage for the mock implementation
    const stored = window.localStorage.getItem('bd-replays');
    const replays: Replay[] = stored ? JSON.parse(stored) : [];
    replays.push(newReplay);
    window.localStorage.setItem('bd-replays', JSON.stringify(replays));
    // In a real implementation, you would upload files and trigger processing here.
    // Redirect to processing page
    router.push(`/processing/${id}`);
  };

  return (
    <div className="px-4 py-8">
      <UploadDropzone onFilesSelected={handleFilesSelected} />
    </div>
  );
}
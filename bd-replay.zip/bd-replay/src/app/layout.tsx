import '../app/globals.css';
import type { Metadata } from 'next';
import BDLayout from '@components/BDLayout';

export const metadata: Metadata = {
  title: 'BD Replay',
  description: 'Capture a place. Revisit it from any angle.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <BDLayout>{children}</BDLayout>
      </body>
    </html>
  );
}
export interface User {
  id: string;
  name: string;
  email: string;
}

export type ReplayStatus =
  | 'draft'
  | 'uploaded'
  | 'processing'
  | 'ready'
  | 'failed';

export interface Replay {
  id: string;
  title: string;
  status: ReplayStatus;
  createdAt: string;
  updatedAt: string;
  cameraPathUrl?: string;
  assetsUrl?: string;
}

export interface SourceMedia {
  id: string;
  replayId: string;
  url: string;
  type: 'video' | 'image';
}

export interface ProcessingJob {
  id: string;
  replayId: string;
  stage:
    | 'uploading'
    | 'extracting'
    | 'estimating'
    | 'reconstructing'
    | 'optimizing'
    | 'ready'
    | 'failed';
  progress: number;
  error?: string;
}

export interface CameraPath {
  id: string;
  replayId: string;
  frames: Array<{ time: number; position: [number, number, number]; lookAt: [number, number, number] }>;
}

export interface ReplayAsset {
  id: string;
  replayId: string;
  url: string;
  type: string;
}

export interface ShareLink {
  id: string;
  replayId: string;
  url: string;
}
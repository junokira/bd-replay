import NeonPanel from './NeonPanel';

export type ProcessingStage =
  | 'uploading'
  | 'extracting'
  | 'estimating'
  | 'reconstructing'
  | 'optimizing'
  | 'ready'
  | 'failed';

interface ProcessingPipelineProps {
  stage: ProcessingStage;
  progress?: number;
}

/**
 * ProcessingPipeline lists the stages of the reconstruction pipeline and indicates the current stage.
 */
export default function ProcessingPipeline({ stage, progress = 0 }: ProcessingPipelineProps) {
  const stages: Array<{ key: ProcessingStage; label: string }> = [
    { key: 'uploading', label: 'Uploading' },
    { key: 'extracting', label: 'Extracting frames' },
    { key: 'estimating', label: 'Mapping camera movement' },
    { key: 'reconstructing', label: 'Reconstructing the scene' },
    { key: 'optimizing', label: 'Optimizing replay' },
    { key: 'ready', label: 'Ready to explore' },
  ];
  return (
    <NeonPanel title="Building your replay" className="max-w-lg mx-auto mt-8">
      <ul className="space-y-2">
        {stages.map(({ key, label }) => {
          const active = key === stage;
          const completed = stages.findIndex((s) => s.key === stage) > stages.findIndex((s) => s.key === key);
          return (
            <li key={key} className="flex items-center">
              <div
                className={`w-3 h-3 mr-3 rounded-full ${completed ? 'bg-green-500' : active ? 'bg-primary animate-pulse' : 'bg-gray-600'}`}
              ></div>
              <span className={active ? 'text-primary' : completed ? 'text-green-500' : 'text-gray-400'}>
                {label}
                {active && stage !== 'ready' && stage !== 'failed' && (
                  <span className="ml-2 text-xs text-gray-500">{Math.round(progress * 100)}%</span>
                )}
              </span>
            </li>
          );
        })}
      </ul>
      {stage === 'failed' && (
        <p className="mt-4 text-red-500 text-sm">Something went wrong during processing. Please try again.</p>
      )}
      {stage === 'ready' && (
        <p className="mt-4 text-green-500 text-sm">Your replay is ready! Click the link above to explore.</p>
      )}
    </NeonPanel>
  );
}
import Link from 'next/link';
import NeonPanel from '@components/NeonPanel';

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center flex-1 px-4 py-20 text-center">
      <h1 className="text-4xl md:text-6xl font-extrabold tracking-wide text-primary mb-4">
        Capture a place.<br /> Revisit it from any angle.
      </h1>
      <p className="max-w-lg text-gray-400 mb-8">
        BD Replay lets you record your surroundings with your phone and replay the moment in
        a fully navigable 3D environment. Walk around your memories like never before.
      </p>
      <Link
        href="/capture"
        className="px-6 py-3 bg-primary text-black font-semibold rounded-lg shadow hover:bg-orange-500 transition-colors"
      >
        Get Started
      </Link>
    </div>
  );
}